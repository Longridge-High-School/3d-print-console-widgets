# Document Viewer for 3D Print Console

Embed text inside 3D Print Console to give your users advice, or provide links to useful sites!